<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_action/action.php';
