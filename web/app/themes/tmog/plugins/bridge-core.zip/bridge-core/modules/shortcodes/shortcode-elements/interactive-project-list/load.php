<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-project-list/interactive-project-list.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-project-list/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-project-list/custom-styles/custom-styles.php';